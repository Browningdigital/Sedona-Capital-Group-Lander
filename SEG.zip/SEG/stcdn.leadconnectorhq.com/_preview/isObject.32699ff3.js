function e(t){var n=typeof t;return t!=null&&(n=="object"||n=="function")}export{e as i};
