import"./entry.6461312a.js";const t=""+new URL("payment-warning.dd3003de.svg",import.meta.url).href;export{t as _};
